import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Crismando } from '../model/crismando.model';
import { StatusControle } from '../model/status-controle.model';
import { environment } from '../../environments/environment';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class InscricaoService {
  private apiUrl = environment.apiUrl + '/api'; // Usando URL do environment

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) { }

  // Helper method to get headers with authentication
  private getAuthHeaders(): HttpHeaders {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    
    try {
      const token = this.authService.getToken();
      if (token) {
        headers = headers.set('Authorization', `Bearer ${token}`);
      }
    } catch (error) {
      console.warn('Erro ao obter token para autenticação:', error);
    }
    
    return headers;
  }

  // Enviar inscrição para o backend
  enviarInscricao(dados: Crismando): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.post(`${this.apiUrl}/inscricoes`, dados, { headers });
  }

  // Enviar inscrição com arquivos (público - sem autenticação)
  enviarInscricaoComArquivos(dados: Crismando, arquivos: { [key: string]: File | null }): Observable<any> {
    const formData = new FormData();
    
    // Adicionar dados da inscrição como JSON string
    formData.append('dadosInscricao', JSON.stringify(dados));
    
    // Adicionar arquivos se existirem
    if (arquivos['documentoIdentidade']) {
      formData.append('documentoIdentidade', arquivos['documentoIdentidade']);
    }
    
    if (arquivos['certidaoBatismo']) {
      formData.append('certidaoBatismo', arquivos['certidaoBatismo']);
    }

    // Endpoint público - não precisa de autenticação
    return this.http.post(`${this.apiUrl}/inscricoes-com-arquivos`, formData);
  }

  // Buscar todas as inscrições
  buscarInscricoes(): Observable<any[]> {
    const headers = this.getAuthHeaders();
    return this.http.get<any[]>(`${this.apiUrl}/inscricoes`, { headers });
  }

  // Upload de arquivo
  uploadArquivo(arquivo: File, campo: string): Observable<any> {
    const formData = new FormData();
    formData.append('arquivo', arquivo);
    formData.append('campo', campo);

    return this.http.post(`${this.apiUrl}/upload`, formData);
  }

  // Testar conexão com o backend (público)
  testarConexao(): Observable<any> {
    return this.http.get(`${this.apiUrl}/test`);
  }

  // Verificar se a tabela existe (público)
  verificarTabela(): Observable<any> {
    return this.http.get(`${this.apiUrl}/check-table`);
  }

  // Corrigir campo comunhao (público)
  corrigirComunhao(): Observable<any> {
    return this.http.post(`${this.apiUrl}/fix-comunhao`, {});
  }

  // Consultar inscrições (com filtros opcionais)
  consultarInscricoes(filtros?: any): Observable<Crismando[]> {
    const headers = this.getAuthHeaders();
    let url = `${this.apiUrl}/inscricoes`;
    
    if (filtros) {
      const params = new URLSearchParams();
      Object.keys(filtros).forEach(key => {
        if (filtros[key] && filtros[key].trim() !== '') {
          params.append(key, filtros[key]);
        }
      });
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
    }
    
    return this.http.get<Crismando[]>(url, { headers });
  }

  // Buscar inscrição por ID
  buscarInscricaoPorId(id: number): Observable<Crismando> {
    const headers = this.getAuthHeaders();
    return this.http.get<Crismando>(`${this.apiUrl}/inscricoes/${id}`, { headers });
  }

  // Atualizar inscrição
  atualizarInscricao(id: number, dados: Crismando): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.put(`${this.apiUrl}/inscricoes/${id}`, dados, { headers });
  }

  // Excluir inscrição
  excluirInscricao(id: number): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.delete(`${this.apiUrl}/inscricoes/${id}`, { headers });
  }

  // Atualizar status da inscrição
  atualizarStatusInscricao(id: number, statusControle: StatusControle): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.post(`${this.apiUrl}/inscricoes/${id}/status`, statusControle, { headers });
  }

  // Buscar status da inscrição
  buscarStatusInscricao(id: number): Observable<StatusControle> {
    const headers = this.getAuthHeaders();
    return this.http.get<StatusControle>(`${this.apiUrl}/inscricoes/${id}/status`, { headers });
  }

  // Buscar histórico de status
  buscarHistoricoStatus(id: number): Observable<StatusControle[]> {
    const headers = this.getAuthHeaders();
    return this.http.get<StatusControle[]>(`${this.apiUrl}/inscricoes/${id}/status/historico`, { headers });
  }
}