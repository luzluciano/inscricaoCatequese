export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000',
  baseUrl: 'http://localhost:3000',
  useLocalData: false // Mudando para false para usar o servidor local
};